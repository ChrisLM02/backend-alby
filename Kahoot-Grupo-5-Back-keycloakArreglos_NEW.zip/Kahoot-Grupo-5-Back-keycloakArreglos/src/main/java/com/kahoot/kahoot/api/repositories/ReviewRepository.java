package com.kahoot.kahoot.api.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kahoot.kahoot.api.entities.Review;

public interface ReviewRepository extends JpaRepository<Review,Integer> {

}
