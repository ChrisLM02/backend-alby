package com.kahoot.kahoot.api.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.MatchDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.servicesimp.MatchServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping(value="/api/v1/matchs")
@RequiredArgsConstructor
@CrossOrigin(origins= {"http://localhost:4200"})
public class MatchController {

    private final MatchServiceImp matchServiceImp;

    @Operation(summary = "Create a new match", description = "Creates a new match", tags = {"matchs"})
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Match created successfully", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "404", description = "Form not found", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "500", description = "Internal server error", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        })
    })
    @PostMapping("/{idForm}")
    public ResponseEntity<Response<MatchDTO>> createMatch(@RequestBody MatchDTO matchDTO, @PathVariable int idForm, @RequestParam List<String> idUsers) {
        return matchServiceImp.save(matchDTO,idForm,idUsers);
    }

    @Operation(summary = "Get all matchs", description = "Gets all matchs", tags = {"matchs"})
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "OK", content = {
            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = MatchDTO.class)))
        }),
        @ApiResponse(responseCode = "500", description = "Internal server error", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        })
    })
    @GetMapping
    public ResponseEntity<Response<List<MatchDTO>>> getAllMatchs() {
        return matchServiceImp.findAll();
    }

    @Operation(summary = "Get match by id", description = "Gets a match by id", tags = {"matchs"})
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Match found", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "404", description = "Match not found", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "500", description = "Internal server error", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        })
    })
    @GetMapping("/{id}")
    public ResponseEntity<Response<MatchDTO>> getMatchById(@PathVariable int id) {
        return matchServiceImp.findById(id);
    }

    @Operation(summary = "Delete match", description = "Deletes a match by id", tags = {"matchs"})
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Match deleted", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "404", description = "Match not found", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "500", description = "Internal server error", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        })
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<MatchDTO>> deleteMatch(@PathVariable int id) {
        return matchServiceImp.delete(id);
    }

    @Operation(summary = "Update match", description = "Updates a match by id", tags = {"matchs"})
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Match updated", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "404", description = "Match not found", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        }),
        @ApiResponse(responseCode = "500", description = "Internal server error", content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))
        })
    })
    @PutMapping("/{id}")
    public ResponseEntity<Response<MatchDTO>> updateMatch(@PathVariable int id, @RequestBody MatchDTO matchDTO) {
        return matchServiceImp.update(matchDTO, id);
    }

}

