package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.ResultDTO;
import com.kahoot.kahoot.api.entities.Result;
import com.kahoot.kahoot.api.other.Response;

public interface ResultService {

    ResponseEntity<Response<ResultDTO>> findById(int id);
    ResponseEntity<Response<ResultDTO>> save(ResultDTO resultDTO, String idUser, int idMatch);
    ResponseEntity<Response<ResultDTO>> delete(int id);
    ResponseEntity<Response<ResultDTO>> update(ResultDTO resultDTO, int id);
    ResponseEntity<Response<List<ResultDTO>>> findAll();

}
