package com.kahoot.kahoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KahootApplication {

	public static void main(String[] args) {
		SpringApplication.run(KahootApplication.class, args);
	}

}
