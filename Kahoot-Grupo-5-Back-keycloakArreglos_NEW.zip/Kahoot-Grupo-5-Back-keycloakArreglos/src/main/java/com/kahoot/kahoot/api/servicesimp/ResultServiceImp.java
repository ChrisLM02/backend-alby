package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.ResultDTO;
import com.kahoot.kahoot.api.entities.Match;
import com.kahoot.kahoot.api.entities.Result;
import com.kahoot.kahoot.api.entities.User;
import com.kahoot.kahoot.api.mappers.ResultMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.MatchRepository;
import com.kahoot.kahoot.api.repositories.ResultRepository;
import com.kahoot.kahoot.api.repositories.UserRepository;
import com.kahoot.kahoot.api.services.ResultService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ResultServiceImp implements ResultService {
	
	private static final Logger logger = LogManager.getLogger();
    private ResultMapper resultMapper;
	private ResultRepository resultRepository;
    private UserRepository userRepository;
    private MatchRepository matchRepository;

    @Override
    public ResponseEntity<Response<ResultDTO>> findById(int id) {
        try {
        	logger.info("Buscando el resultado con el id " + id);
        	Result result = resultRepository.findById(id).orElse(null);
            if (result != null) {
            	logger.info("Se ha encontrado el resultado");
                ResultDTO resultDTO = resultMapper.toDTO(result);
                return ResponseEntity.ok(new Response<ResultDTO>("Se ha encontrado el resultado", resultDTO));
            }
            logger.warn("El resultado con el id " + id + " no existe");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<ResultDTO>(
                    "El resultado con el id " + id + " no existe", null));
        } catch (Exception e) {
        	logger.error("Error al buscar el resultado con el id " + id, e);
        	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<Response<ResultDTO>> delete(int id) {
        try {
        	logger.info("Borrando el resultado con el id " + id);
        	Result result = resultRepository.findById(id).orElse(null);
            if (result != null) {
            	logger.info("Se ha borrado el resultado");
                ResultDTO resultDTO = resultMapper.toDTO(result);
                resultRepository.delete(result);
                return ResponseEntity.ok(new Response<ResultDTO>("Se ha borrado el resultado", resultDTO));
            }
            logger.warn("El resultado con el id " + id + " no existe");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<ResultDTO>(
                    "El resultado con el id " + id + " no existe", null));
        } catch (Exception e) {
        	logger.error("Error al borrar el resultado con el id " + id, e);
        	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<Response<ResultDTO>> update(ResultDTO resultDTO, int id) {
        try {
        	logger.info("Actualizando el resultado con el id " + id);
        	Result result = resultRepository.findById(id).orElse(null);
            if (result != null) {
            	logger.info("Se ha actualizado el resultado");
                result.setScore(resultDTO.getScore());
                resultRepository.save(result);
                ResultDTO updatedResultDTO = resultMapper.toDTO(result);
                return ResponseEntity.ok(new Response<ResultDTO>("Se ha actualizado el resultado", updatedResultDTO));
            }
            logger.warn("El resultado con el id " + id + " no existe");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<ResultDTO>(
                    "El resultado con el id " + id + " no existe", null));
        } catch (Exception e) {
        	logger.error("Error al actualizar el resultado con el id " + id, e);
        	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<Response<List<ResultDTO>>> findAll() {
        try {
        	logger.info("Buscando todos los resultados");
        	List<Result> results = resultRepository.findAll();
            List<ResultDTO> resultDTOs = new ArrayList<>();
            for (Result result : results) {
                ResultDTO resultDTO = resultMapper.toDTO(result);
                resultDTOs.add(resultDTO);
            }
            return ResponseEntity.ok(new Response<List<ResultDTO>>("Se han encontrado los resultados", resultDTOs));
        } catch (Exception e) {
        	logger.error("Error al buscar los resultados", e);
        	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<Response<ResultDTO>> save(ResultDTO resultDTO, String idUser, int idMatch) {
        try {
        	logger.info("Guardando el resultado");
            User user = userRepository.findById(idUser).orElse(null);
            Match match = matchRepository.findById(idMatch).orElse(null);
            if (user != null && match != null) {
                Result result = resultMapper.toEntity(resultDTO);
                resultRepository.save(result);
                user.addResults(result);
                match.addResults(result);
                matchRepository.save(match);
                userRepository.save(user);
                ResultDTO savedResultDTO = resultMapper.toDTO(result);
                return ResponseEntity.ok(new Response<ResultDTO>("Se ha guardado el resultado", savedResultDTO));
            }
            if (user == null) {
                logger.warn("El usuario con el id " + idUser + " no existe");
                return ResponseEntity.badRequest().body(new Response<ResultDTO>("El usuario con el id " + idUser + " no existe",
                        null));
            }
            logger.warn("El partido con el id " + idMatch + " no existe");
            return ResponseEntity.badRequest().body(
                    new Response<ResultDTO>("El partido con el id " + idMatch + " no existe", null));
        } catch (Exception e) {
        	logger.error("Error al guardar el resultado", e);
        	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

}

