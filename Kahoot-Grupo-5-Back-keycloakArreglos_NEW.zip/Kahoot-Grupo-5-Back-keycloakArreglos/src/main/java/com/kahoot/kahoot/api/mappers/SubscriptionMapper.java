package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;
/*
public interface SubscriptionMapper {

    SubscriptionMapper INSTANCE = Mappers.getMapper(SubscriptionMapper.class);
    //name,price,subscribers,description,users
    //name,price,subscribers,descriptions,users
    @Mapping(source = "name", target = "name")
    @Mapping(source = "price", target = "price")
    @Mapping(source = "subscribers", target = "subscribers")
    @Mapping(source = "description", target = "description")
    @Mapping(source = "users", target = "users")
    SubscriptionDTO subscriptionToSubscriptionDTO(Subscription subscription);

    @Mapping(source = "name", target = "name")
    @Mapping(source = "price", target = "price")
    @Mapping(source = "subscribers", target = "subscribers")
    @Mapping(source = "description", target = "description")
    @Mapping(source = "users", target = "users")
    Subscription subscriptionDTOToSubscription(SubscriptionDTO subscriptionDTO);

}

 */

import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.SubscriptionDTO;
import com.kahoot.kahoot.api.entities.Subscription;

@Component




public class SubscriptionMapper {
 




    public SubscriptionDTO toDTO(Subscription subscription) {
        SubscriptionDTO subscriptionDTO = null;
        if (subscription != null) {
            subscriptionDTO = new SubscriptionDTO();
            subscriptionDTO.setId(subscription.getId());
           subscriptionDTO.setName(subscription.getName());
          
            subscriptionDTO.setPrice(subscription.getPrice());
           
            subscriptionDTO.setDescription(subscription.getDescription());
            subscriptionDTO.setSubscribers(subscription.getSubscribers());
            
        }
        return subscriptionDTO;
    }

    public Subscription toEntity(SubscriptionDTO subscriptionDTO) {
        Subscription subscription = null;
        if (subscriptionDTO != null) {
            subscription = new Subscription();
            subscription.setId(subscriptionDTO.getId());
            subscription.setName(subscriptionDTO.getName());
            subscription.setPrice(subscriptionDTO.getPrice());
            subscription.setSubscribers(subscriptionDTO.getSubscribers());
            subscription.setDescription(subscriptionDTO.getDescription());
            
        }
        return subscription;
    }



    public List<SubscriptionDTO> toDTOList(List<Subscription> userList) {
        return userList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Subscription> toEntityList(List<SubscriptionDTO> userDTOList) {
        return userDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }

}
