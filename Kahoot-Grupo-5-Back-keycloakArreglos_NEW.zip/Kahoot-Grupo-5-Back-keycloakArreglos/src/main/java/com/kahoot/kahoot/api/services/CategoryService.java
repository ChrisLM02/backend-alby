package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.CategoryDTO;
import com.kahoot.kahoot.api.entities.Category;
import com.kahoot.kahoot.api.other.Response;

public interface CategoryService {
    ResponseEntity<Response<CategoryDTO>> findById(int id);
    ResponseEntity<Response<CategoryDTO>> save(CategoryDTO categoryDTO);
    ResponseEntity<Response<CategoryDTO>> delete(int id);
    ResponseEntity<Response<CategoryDTO>> update(CategoryDTO categoryDTO, int id);
    ResponseEntity<Response<List<CategoryDTO>>> findAll();



}
