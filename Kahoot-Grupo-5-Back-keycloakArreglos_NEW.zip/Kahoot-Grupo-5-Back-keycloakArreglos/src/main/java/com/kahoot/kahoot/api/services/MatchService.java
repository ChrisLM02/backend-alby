package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.MatchDTO;
import com.kahoot.kahoot.api.entities.Match;
import com.kahoot.kahoot.api.other.Response;

public interface MatchService {
    ResponseEntity<Response<MatchDTO>> findById(int id);
    ResponseEntity<Response<MatchDTO>> findByPin(int pin);
   ResponseEntity<Response<MatchDTO>> save(MatchDTO matchDTO, int idForm, List<String> idUsers);
    ResponseEntity<Response<MatchDTO>> delete(int id);
    ResponseEntity<Response<MatchDTO>> update(MatchDTO matchDTO, int id);
    ResponseEntity<Response<List<MatchDTO>>> findAll();


}
