package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.MatchDTO;
import com.kahoot.kahoot.api.entities.Match;

@Component
public class MatchMapper {


    @Autowired
    FormMapper formMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    ResultMapper resultMapper;

    public MatchDTO toDTO(Match match) {
        MatchDTO matchDTO = null;
        if (match != null) {
            matchDTO = new MatchDTO();
            matchDTO.setId(match.getId());
            matchDTO.setForm(formMapper.toDTO(match.getForm()));
            matchDTO.setUsers(userMapper.toDTOList(match.getUsers()));
            matchDTO.setPin(match.getPin());
            matchDTO.setPlayers(match.getPlayers());
            matchDTO.setPassword(match.getPassword());
            matchDTO.setResults(resultMapper.toDTOList(match.getResults()));

        }
        return matchDTO;
    }


    public Match toEntity(MatchDTO matchDTO) {
        Match match = null;
        if (matchDTO != null) {
            match = new Match();
            match.setId(matchDTO.getId());
            match.setForm(formMapper.toEntity(matchDTO.getForm()));
         
            match.setUsers(userMapper.toEntityList(matchDTO.getUsers()));
            match.setPin(matchDTO.getPin());
            match.setPlayers(matchDTO.getPlayers());
            match.setPassword(matchDTO.getPassword());
            match.setResults(resultMapper.toEntityList(matchDTO.getResults()));
        }
        return match;
    }


    public List<MatchDTO> toDTOList(List<Match> matchList) {
        return matchList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Match> toEntityList(List<MatchDTO> matchDTOList) {
        return matchDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }


}