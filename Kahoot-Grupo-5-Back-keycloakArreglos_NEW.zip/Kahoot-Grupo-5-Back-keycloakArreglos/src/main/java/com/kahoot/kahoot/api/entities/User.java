package com.kahoot.kahoot.api.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "users")
public class User implements Serializable {

    @Id
    String id;

    @ManyToOne
    @JsonManagedReference
    private Subscription subscription;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Result> results;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Review> review;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Form> forms;

    public void addResults(Result result) {
        if (this.results == null) {
            this.results = new ArrayList<>();
        }
        this.results.add(result);
    }

    public void addForms(Form form) {
        if (forms == null) {
            forms = new ArrayList<>();
        }
        forms.add(form);
    }

    public void addReviews(Review review) {

        if (this.review == null) {
            this.review = new ArrayList<>();
        }
        this.review.add(review);
    }

}
