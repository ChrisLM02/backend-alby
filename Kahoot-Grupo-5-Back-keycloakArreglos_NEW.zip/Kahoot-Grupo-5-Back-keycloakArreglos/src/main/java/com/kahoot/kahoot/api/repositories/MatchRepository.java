package com.kahoot.kahoot.api.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kahoot.kahoot.api.entities.Match;





public interface MatchRepository extends JpaRepository<Match,Integer>{
    Optional<Match> findByPin(Integer pin);

}
