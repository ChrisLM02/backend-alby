package com.kahoot.kahoot.api.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kahoot.kahoot.api.entities.Answer;

public interface AnswerRepository extends JpaRepository<Answer,Integer>{
    
}