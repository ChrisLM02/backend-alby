package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.CategoryDTO;
import com.kahoot.kahoot.api.entities.Category;

@Component
public class CategoryMapper {
    @Autowired
    FormMapper formMapper;


    public CategoryDTO toDTO(Category category) {
        CategoryDTO categoryDTO = null;
        if (category != null) {
            categoryDTO = new CategoryDTO();
            categoryDTO.setId(category.getId());
            categoryDTO.setName(category.getName());
        }
        return categoryDTO;
    }


    public Category toEntity(CategoryDTO categoryDTO) {
        Category category = null;
        if (categoryDTO != null) {
            category = new Category();
            category.setId(categoryDTO.getId());
            category.setName(categoryDTO.getName());
        }
        return category;
    }


    public List<CategoryDTO> toDTOList(List<Category> categoryList) {
        return categoryList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Category> toEntityList(List<CategoryDTO> categoryDTOList) {
        return categoryDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }


}