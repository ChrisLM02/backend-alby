package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.AnswerDTO;
import com.kahoot.kahoot.api.entities.Answer;
import com.kahoot.kahoot.api.other.Response;

public interface AnswerService {

    ResponseEntity<Response<AnswerDTO>> findById(int id);
    ResponseEntity<Response<AnswerDTO>> save(AnswerDTO answerDTO, int idQuestion);
    ResponseEntity<Response<AnswerDTO>> delete(int id);
    ResponseEntity<Response<AnswerDTO>> update(AnswerDTO answerDTO, int id);
    ResponseEntity<Response<List<AnswerDTO>>> findAll();
    

}
