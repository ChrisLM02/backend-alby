package com.kahoot.kahoot.api.dtos;





import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserDTO {

    String id;
    String email;
    String username;
    String name;
    String password;
    private Set<String> roles;


}
