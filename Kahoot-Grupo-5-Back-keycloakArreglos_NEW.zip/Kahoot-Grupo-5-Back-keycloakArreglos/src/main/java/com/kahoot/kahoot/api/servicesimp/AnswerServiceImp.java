package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.AnswerDTO;
import com.kahoot.kahoot.api.entities.Answer;
import com.kahoot.kahoot.api.entities.Question;
import com.kahoot.kahoot.api.mappers.AnswerMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.AnswerRepository;
import com.kahoot.kahoot.api.repositories.QuestionRepository;
import com.kahoot.kahoot.api.services.AnswerService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AnswerServiceImp implements AnswerService {
    private static final Logger logger = LogManager.getLogger();

    private AnswerRepository answerRepository;
    private QuestionRepository questionRepository;
    private AnswerMapper answerMapper;

    @Override
    public ResponseEntity<Response<AnswerDTO>> findById(int id) {
        try {
            if (id <= 0) {
                logger.error("Error: el identificador de la respuesta debe ser mayor a 0. Se ha recibido: " + id);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: el identificador de la respuesta debe ser mayor a 0", null));
            }
            Answer answer = answerRepository.findById(id).orElse(null);
            if (answer == null) {
                logger.error("No se ha encontrado la respuesta con id " + id);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: no se ha encontrado la respuesta con id " + id, null));
            }
            AnswerDTO answerDTO = answerMapper.toDTO(answer);
            logger.info("Se ha encontrado la respuesta con id " + id);
            return ResponseEntity.ok(new Response<AnswerDTO>("Se ha encontrado la respuesta", answerDTO));
        } catch (Exception e) {
            logger.error("Error interno del servidor al buscar la respuesta con id " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<AnswerDTO>("Error interno del servidor", null));
        }
    }

    @Override
    public ResponseEntity<Response<AnswerDTO>> delete(int id) {
        try {
            if (id <= 0) {
                logger.error("Error: el identificador de la respuesta debe ser mayor a 0. Se ha recibido: " + id);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: el identificador de la respuesta debe ser mayor a 0", null));
            }
            Answer deletedAnswer = answerRepository.findById(id).orElse(null);
            if (deletedAnswer == null) {
                logger.error("No se ha encontrado la respuesta con id " + id);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: no se ha encontrado la respuesta con id " + id, null));
            }
            answerRepository.delete(deletedAnswer);
            AnswerDTO answerDTO = answerMapper.toDTO(deletedAnswer);
            logger.info("Se ha borrado la respuesta con id " + id);
            return ResponseEntity.ok(new Response<AnswerDTO>("Se ha borrado la respuesta", answerDTO));
        } catch (Exception e) {
            logger.error("Error interno del servidor al borrar la respuesta con id " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<AnswerDTO>("Error interno del servidor", null));
        }
    }

    @Override
    public ResponseEntity<Response<AnswerDTO>> update(AnswerDTO answerDTO, int id) {
        try {
            if (id <= 0 || answerDTO == null) {
                logger.error("Error: el identificador de la respuesta o la respuesta no puede ser nula. Se han recibido: " + id + " y " + answerDTO);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: el identificador de la respuesta o la respuesta no puede ser nula", null));
            }
            Answer updatedAnswer = answerRepository.findById(id).orElse(null);
            if (updatedAnswer == null) {
                logger.error("No se ha encontrado la respuesta con id " + id);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: no se ha encontrado la respuesta con id " + id, null));
            }
            updatedAnswer.setContent(answerDTO.getContent());
            updatedAnswer.setCorrect(answerDTO.isCorrect());
            answerRepository.save(updatedAnswer);
            AnswerDTO updatedAnswerDTO = answerMapper.toDTO(updatedAnswer);
            logger.info("Se ha actualizado la respuesta con id " + id);
            return ResponseEntity.ok(new Response<AnswerDTO>("Se ha actualizado la respuesta", updatedAnswerDTO));
        } catch (Exception e) {
            logger.error("Error interno del servidor al actualizar la respuesta con id " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<AnswerDTO>("Error interno del servidor", null));
        }
    }

    @Override
    public ResponseEntity<Response<List<AnswerDTO>>> findAll() {
        try {
            List<Answer> answers = answerRepository.findAll();
            List<AnswerDTO> answerDTOs = new ArrayList<>();
            for (Answer answer : answers) {
                AnswerDTO answerDTO = answerMapper.toDTO(answer);
                answerDTOs.add(answerDTO);
            }
            logger.info("Se han encontrado las respuestas");
            return ResponseEntity.ok(new Response<List<AnswerDTO>>("Se han encontrado las respuestas", answerDTOs));
        } catch (Exception e) {
            logger.error("Error interno del servidor al buscar las respuestas", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<List<AnswerDTO>>("Error interno del servidor", null));
        }
    }

    @Override
    public ResponseEntity<Response<AnswerDTO>> save(AnswerDTO answerDTO, int idQuestion) {
        try{
            if (answerDTO == null || idQuestion <= 0) {
                logger.error("Error: la respuesta o el identificador de la pregunta no puede ser nulo");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: la respuesta o el identificador de la pregunta no puede ser nulo", null));
            }
            logger.info("Se ha recibido una solicitud para crear una respuesta");
            Question question = questionRepository.findById(idQuestion).orElse(null);
            if (question == null) {
                logger.error("No se ha encontrado la pregunta con id " + idQuestion);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<AnswerDTO>("Error: no se ha encontrado la pregunta con id " + idQuestion, null));
            }
            logger.info("Se ha encontrado la pregunta con id " + idQuestion);
            Answer answer = new Answer();
            answer.setContent(answerDTO.getContent());
            answer.setCorrect(answerDTO.isCorrect());
            answer.setQuestion(question);
            logger.info("Se ha creado la respuesta");
            answerRepository.save(answer);
            logger.info("Se ha guardado la respuesta");
            question.addAnswers(answer);
            questionRepository.save(question);
            logger.info("Se ha agregado la respuesta a la pregunta");

            AnswerDTO savedAnswerDTO = answerMapper.toDTO(answer);
            logger.info("Se ha creado el objeto AnswerDTO");
            return ResponseEntity.status(HttpStatus.CREATED).body(new Response<>("Se ha creado la respuesta", savedAnswerDTO));
        } catch (Exception e) {
            logger.error("Error interno del servidor", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<AnswerDTO>("Error interno del servidor", null));
        }
    }

}