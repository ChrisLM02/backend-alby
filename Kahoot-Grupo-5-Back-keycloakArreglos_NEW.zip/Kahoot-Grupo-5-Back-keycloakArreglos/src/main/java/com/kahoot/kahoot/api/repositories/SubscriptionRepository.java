package com.kahoot.kahoot.api.repositories;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kahoot.kahoot.api.entities.Subscription;

public interface SubscriptionRepository extends JpaRepository<Subscription,Integer>{

    Optional<Subscription> findByName(String name);

}
