package com.kahoot.kahoot.api.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.ReviewDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.servicesimp.ReviewServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping(value="/api/v1/reviews")
@RequiredArgsConstructor
@CrossOrigin(origins= {"http://localhost:4200"})
public class ReviewController {

    private ReviewServiceImp reviewServiceImp;

    @Operation(summary = "Create a review", description = "Creates a review", tags = { "Review" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "The review has been created", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping
    public ResponseEntity<Response<ReviewDTO>> createReview(@RequestBody ReviewDTO reviewDTO, @RequestParam String idUser, @RequestParam int idForm) {
        return reviewServiceImp.save(reviewDTO, idUser, idForm);
    }

    @Operation(summary = "Get all reviews", description = "Get all reviews", tags = { "Review" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "The reviews have been retrieved", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "The reviews could not be found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping
    public ResponseEntity<Response<List<ReviewDTO>>> getAlReviews() {
        return reviewServiceImp.findAll();
    }

    @Operation(summary = "Get a review by id", description = "Get a review by id", tags = { "Review" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "The review has been retrieved", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "The review could not be found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping("/{id}")
    public ResponseEntity<Response<ReviewDTO>> getReviewById(@PathVariable int id) {
        return reviewServiceImp.findById(id);
    }

    @Operation(summary = "Delete a review", description = "Delete a review", tags = { "Review" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "The review has been deleted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "The review could not be found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<ReviewDTO>> deleteReview(@PathVariable int id) {
        return reviewServiceImp.delete(id);
    }

    @Operation(summary = "Update a review", description = "Update a review", tags = { "Review" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "The review has been updated", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "The review could not be found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PutMapping("/{id}")
    public ResponseEntity<Response<ReviewDTO>> updateReview(@PathVariable int id, @RequestBody ReviewDTO reviewDTO) {
        return reviewServiceImp.update(reviewDTO, id);
    }

}

