package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.AnswerDTO;
import com.kahoot.kahoot.api.entities.Answer;

@Component
public class AnswerMapper {
    

    public AnswerDTO toDTO(Answer answer) {
        AnswerDTO answerDTO = null;
        if (answer != null) {
            answerDTO = new AnswerDTO();
            answerDTO.setId(answer.getId());
            answerDTO.setContent(answer.getContent());
 
            answerDTO.setCorrect(answer.isCorrect());
        }
        return answerDTO;
    }


    public Answer toEntity(AnswerDTO answerDTO) {
        Answer answer = null;
        if (answerDTO != null) {
            answer = new Answer();
            answer.setId(answerDTO.getId());
            answer.setCorrect(answerDTO.isCorrect());
   
            answer.setContent(answerDTO.getContent());
        }
        return answer;
    }


    public List<AnswerDTO> toDTOList(List<Answer> answerList) {
        return answerList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Answer> toEntityList(List<AnswerDTO> answerDTOList) {
        return answerDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }


}