package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.ReviewDTO;
import com.kahoot.kahoot.api.entities.Form;
import com.kahoot.kahoot.api.entities.Review;
import com.kahoot.kahoot.api.entities.User;
import com.kahoot.kahoot.api.mappers.ReviewMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.FormRepository;
import com.kahoot.kahoot.api.repositories.ReviewRepository;
import com.kahoot.kahoot.api.repositories.UserRepository;
import com.kahoot.kahoot.api.services.ReviewService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ReviewServiceImp implements ReviewService {
	
	private static final Logger logger = LogManager.getLogger();
	private ReviewMapper reviewMapper;
    private ReviewRepository reviewRepository;
    private UserRepository userRepository;
    private FormRepository formRepository;

    @Override
    public ResponseEntity<Response<ReviewDTO>> findById(int id) {
        try {
            logger.info("Buscando review con id {}", id);
            Review review = reviewRepository.findById(id).orElse(null);
            if(review == null) {
                logger.warn("La review con id {} no existe", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<ReviewDTO>("La review buscada no existe", null));
            } else {
                logger.info("Se ha encontrado la review con id {}", id);
                ReviewDTO reviewDTO = reviewMapper.toDTO(review);
                return ResponseEntity.ok(new Response<ReviewDTO>("Se ha encontrado la review", reviewDTO));
            }
        } catch (Exception e) {
            logger.error("Error en el método findById: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<ReviewDTO>("Error 500", null));
        }
        
    }

    

    @Override
    public ResponseEntity<Response<ReviewDTO>> delete(int id) {
        try {
            logger.info("Borrando review con id {}", id);
            Review deletedReview = reviewRepository.findById(id).orElse(null);
            if(deletedReview == null) {
                logger.warn("La review con id {} no existe para borrar", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<ReviewDTO>("La review buscada para eliminar no existe", null));
            } else {
                logger.info("Se ha borrado la review con id {}", id);
                reviewRepository.delete(deletedReview);
                ReviewDTO reviewDTO = reviewMapper.toDTO(deletedReview);
                return ResponseEntity.ok(new Response<ReviewDTO>("Se ha borrado la review", reviewDTO));
            }
        } catch (Exception e) {
            logger.error("Error en el método delete: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<ReviewDTO>("Error 500", null));
        }
    }

    @Override
    public ResponseEntity<Response<ReviewDTO>> update(ReviewDTO reviewDTO, int id) {
        try {
            logger.info("Actualizando review con id {}", id);
            Review updatedReview = reviewRepository.findById(id).orElse(null);
            if(updatedReview == null) {
                logger.warn("La review con id {} no existe para actualizar", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<ReviewDTO>("La review buscada para actualizar no existe", null));
            } else {
                logger.info("Se ha actualizado la review con id {}", id);
                updatedReview.setScore(reviewDTO.getScore());
    
                reviewRepository.save(updatedReview);
                ReviewDTO updatedReviewDTO  = reviewMapper.toDTO(updatedReview);
                return ResponseEntity.ok(new Response<ReviewDTO>("Se ha actualizado la review", updatedReviewDTO ));
            }
        } catch (Exception e) {
            logger.error("Error en el método update: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<ReviewDTO>("Error 500", null));
        }
    }

    @Override
    public ResponseEntity<Response<List<ReviewDTO>>> findAll() {
        try {
            logger.info("Buscando todas las reviews");
            List<Review> reviews = reviewRepository.findAll();
            List<ReviewDTO> reviewDTOs = new ArrayList<>();
            for (Review review : reviews) {
                ReviewDTO reviewDTO = reviewMapper.toDTO(review);
                reviewDTOs.add(reviewDTO);
            }
            logger.info("Se han encontrado {} reviews", reviewDTOs.size());
            return ResponseEntity.ok(new Response<List<ReviewDTO>>("Se han encontrado las reviews", reviewDTOs));
        } catch (Exception e) {
            logger.error("Error en el método findAll: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<List<ReviewDTO>>("Error 500", null));
        }
     }



    @Override
    public ResponseEntity<Response<ReviewDTO>> save(ReviewDTO reviewDTO, String idUser, int idForm) {
        try {
            logger.info("Guardando nueva review con id de formulario {} y id de usuario {}", idForm, idUser);
            User user = userRepository.findById(idUser).orElse(null);
            Form form = formRepository.findById(idForm).orElse(null);
            if(user == null || form == null) {
                logger.warn("Los ids de usuario o formulario no existen");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<ReviewDTO>("Los ids de usuario o formulario no existen", null));
            } else {
                logger.info("Se ha creado la review con id de formulario {} y id de usuario {}", idForm, idUser);
                Review review = reviewMapper.toEntity(reviewDTO);
                reviewRepository.save(review);
                user.addReviews(review);
                form.addReviews(review);
                userRepository.save(user);
                formRepository.save(form);
                ReviewDTO savedReviewDTO  = reviewMapper.toDTO(review);
                return ResponseEntity.ok(new Response<ReviewDTO>("Se ha creado la review", savedReviewDTO ));
            }
        } catch (Exception e) {
            logger.error("Error en el método save: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<ReviewDTO>("Error 500", null));
        }
        
        

    }

}


