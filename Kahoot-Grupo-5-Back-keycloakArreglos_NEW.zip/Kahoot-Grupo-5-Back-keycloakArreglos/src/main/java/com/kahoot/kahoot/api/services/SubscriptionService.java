package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.SubscriptionDTO;
import com.kahoot.kahoot.api.entities.Subscription;
import com.kahoot.kahoot.api.other.Response;

public interface SubscriptionService {
    ResponseEntity<Response<SubscriptionDTO>> findById(int id);
    ResponseEntity<Response<SubscriptionDTO>> findByName(String name);
    ResponseEntity<Response<SubscriptionDTO>> save(SubscriptionDTO subscriptionDTO);
    ResponseEntity<Response<SubscriptionDTO>> delete(int id);
    ResponseEntity<Response<SubscriptionDTO>> update(SubscriptionDTO subscriptionDTO , int id);
    ResponseEntity<Response<List<SubscriptionDTO>>> findAll();
}
