package com.kahoot.kahoot.api.controllers;


import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.SubscriptionDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.servicesimp.SubscriptionServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping(value="/api/v1/subscriptions")
@RequiredArgsConstructor
@CrossOrigin(origins= {"http://localhost:4200"})
public class SubscriptionController {

    private final SubscriptionServiceImp subscriptionServiceImp;


    @Operation(summary = "Create a subscription", description = "Create a subscription", tags={ "subscription" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Subscription created", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SubscriptionDTO.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @PostMapping
    public ResponseEntity<Response<SubscriptionDTO>> createSubscription(@RequestBody SubscriptionDTO subscriptionDTO) {
        return subscriptionServiceImp.save(subscriptionDTO);
    }

    @Operation(summary = "Retrieve all subscriptions", description = "Retrieve all subscriptions", tags={ "subscription" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "List of subscriptions", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SubscriptionDTO.class))),
            @ApiResponse(responseCode = "404", description = "No subscriptions found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @GetMapping
    public ResponseEntity<Response<List<SubscriptionDTO>>> getAlSubscriptions() {
        return subscriptionServiceImp.findAll();
    }

    @Operation(summary = "Retrieve subscription by id", description = "Retrieve subscription by id", tags={ "subscription" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Subscription retrieved", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SubscriptionDTO.class))),
            @ApiResponse(responseCode = "404", description = "Subscription not found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @GetMapping("/{id}")
    public ResponseEntity<Response<SubscriptionDTO>> getSubscriptionById(@PathVariable int id) {
        return subscriptionServiceImp.findById(id);
    }

    @Operation(summary = "Delete subscription by id", description = "Delete subscription by id", tags={ "subscription" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Subscription deleted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SubscriptionDTO.class))),
            @ApiResponse(responseCode = "404", description = "Subscription not found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<SubscriptionDTO>> deleteSubscription(@PathVariable int id) {
        return subscriptionServiceImp.delete(id);
    }

    @Operation(summary = "Update subscription by id", description = "Update subscription by id", tags={ "subscription" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Subscription updated", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SubscriptionDTO.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input", content = @Content),
            @ApiResponse(responseCode = "404", description = "Subscription not found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @PutMapping("/{id}")
    public ResponseEntity<Response<SubscriptionDTO>> updateSubscription(@PathVariable int id, @RequestBody SubscriptionDTO subscriptionDTO) {
        return subscriptionServiceImp.update(subscriptionDTO, id);
    }



}


