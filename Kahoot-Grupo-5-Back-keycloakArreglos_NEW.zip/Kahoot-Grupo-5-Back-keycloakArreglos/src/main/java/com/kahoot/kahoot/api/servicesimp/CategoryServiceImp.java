package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.CategoryDTO;
import com.kahoot.kahoot.api.entities.Category;
import com.kahoot.kahoot.api.mappers.CategoryMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.CategoryRepository;
import com.kahoot.kahoot.api.services.CategoryService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CategoryServiceImp implements CategoryService {
    private CategoryMapper categoryMapper;
    private static final Logger logger = LogManager.getLogger();
    private CategoryRepository categoryRepository;

    @Override
    public ResponseEntity<Response<CategoryDTO>> findById(int id) {
        try {
            logger.info("Intentando encontrar la categoria con id: " + id);
            Category category = categoryRepository.findById(id).orElse(null);
            if (category == null) {
                logger.warn("Categoria no encontrada con id: " + id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<CategoryDTO>("Categoria no encontrada", null));
            }

            CategoryDTO categoryDTO = categoryMapper.toDTO(category);
            logger.info("Categoria encontrada: " + categoryDTO.toString());
            return ResponseEntity.ok(new Response<CategoryDTO>("Se ha encontrado la categoria", categoryDTO));
        } catch (Exception e) {
            logger.error("Error 500 en findById de CategoryServiceImp", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<CategoryDTO>("Error en el servidor", null));
        }
    }

    @Override
    public ResponseEntity<Response<CategoryDTO>> save(CategoryDTO categoryDTO) {
        try {
            logger.info("Intentando guardar la categoria: " + categoryDTO.toString());
            if (categoryDTO.getName() == null) {
                logger.warn("El nombre no puede ser nulo");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<CategoryDTO>("El nombre no puede ser nulo", null));
            }

            Category categoryToSave = categoryMapper.toEntity(categoryDTO);
            Category savedCategory = categoryRepository.save(categoryToSave);
            CategoryDTO savedCategoryDTO = categoryMapper.toDTO(savedCategory);
            logger.info("Categoria guardada: " + savedCategoryDTO.toString());
            return ResponseEntity.status(HttpStatus.CREATED).body(new Response<CategoryDTO>("Se ha guardado la categoria", savedCategoryDTO));

        } catch (Exception e) {
            logger.error("Error 500 en save de CategoryServiceImp", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<CategoryDTO>("Error en el servidor", null));
        }

    }

    @Override
    public ResponseEntity<Response<CategoryDTO>> delete( int id) {
        try {
            logger.info("Intentando eliminar la categoria con id: " + id);
            Category deletedCategory = categoryRepository.findById(id).orElse(null);
            if (deletedCategory == null) {
                logger.warn("Categoria no encontrada con id: " + id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<CategoryDTO>("Categoria no encontrada", null));
            }

            categoryRepository.delete(deletedCategory);
            CategoryDTO categoryDTO = categoryMapper.toDTO(deletedCategory);
            logger.info("Categoria eliminada: " + categoryDTO.toString());
            return ResponseEntity.ok(new Response<CategoryDTO>("Se ha eliminado la categoria", categoryDTO));

        } catch (Exception e) {
            logger.error("Error 500 en delete de CategoryServiceImp", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<CategoryDTO>("Error en el servidor", null));
        }

    }

    @Override
    public ResponseEntity<Response<CategoryDTO>> update(CategoryDTO categoryDTO, int id) {
        try {
            logger.info("Intentando actualizar la categoria con id: " + id);
            Category updatedCategory = categoryRepository.findById(id).orElse(null);
            if (updatedCategory == null) {
                logger.warn("Categoria no encontrada con id: " + id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<CategoryDTO>("Categoria no encontrada", null));
            }
            
            if (categoryDTO.getName() == null) {
                logger.warn("El nombre no puede ser nulo");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Response<CategoryDTO>("El nombre no puede ser nulo", null));
            }
            

            updatedCategory.setName(categoryDTO.getName());
            categoryRepository.save(updatedCategory);
            CategoryDTO newCategoryDTO = categoryMapper.toDTO(updatedCategory);
            logger.info("Categoria actualizada: " + newCategoryDTO.toString());
            return ResponseEntity.ok(new Response<CategoryDTO>("Se ha actualizado la categoria", newCategoryDTO));
            
        } catch (Exception e) {
            logger.error("Error 500 en update de CategoryServiceImp", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<CategoryDTO>("Error en el servidor", null));
        }
        
    }

    @Override
    public ResponseEntity<Response<List<CategoryDTO>>> findAll() {
        try {
            logger.info("Intentando encontrar todas las categorias");
            List<Category> categories = categoryRepository.findAll();
            List<CategoryDTO> categoryDTOs = new ArrayList<>();
            for (Category category : categories) {
                CategoryDTO categoryDTO = categoryMapper.toDTO(category);
                categoryDTOs.add(categoryDTO);
                
            }
            
            logger.info("Cantidad de categorias encontradas: " + categoryDTOs.size());
            return ResponseEntity.ok(new Response<List<CategoryDTO>>("Se han encontrado las categorias", categoryDTOs));
        } catch (Exception e) {
            logger.error("Error 500 en findAll de CategoryServiceImp", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<List<CategoryDTO>>("Error en el servidor", null));
        }
    }

}

