package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.QuestionDTO;
import com.kahoot.kahoot.api.entities.Question;

@Component
public class QuestionMapper {
    
    @Autowired
    AnswerMapper answerMapper;

    public QuestionDTO toDTO(Question question) {
        QuestionDTO questionDTO = null;
        if (question != null) {
            questionDTO = new QuestionDTO();
            questionDTO.setId(question.getId());
            questionDTO.setTimer(question.getTimer());
            questionDTO.setTitle(question.getTitle());
         
            questionDTO.setAnswers(answerMapper.toDTOList(question.getAnswers()));
        }
        return questionDTO;
    }


    public Question toEntity(QuestionDTO questionDTO) {
        Question question = null;
        if (questionDTO != null) {
            question = new Question();
            question.setId(questionDTO.getId());
            question.setTimer(questionDTO.getTimer());
      
            question.setTitle(questionDTO.getTitle());
            question.setAnswers(answerMapper.toEntityList(questionDTO.getAnswers()));
        }
        return question;
    }


    public List<QuestionDTO> toDTOList(List<Question> questionList) {
        return questionList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Question> toEntityList(List<QuestionDTO> questionDTOList) {
        return questionDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }


}