package com.kahoot.kahoot.api.servicesimp;

import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.keycloak.OAuth2Constants;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.UserDTO;
import com.kahoot.kahoot.api.entities.User;
import com.kahoot.kahoot.api.repositories.SubscriptionRepository;
import com.kahoot.kahoot.api.repositories.UserRepository;
import com.kahoot.kahoot.api.services.IKeycloakService;
import com.kahoot.kahoot.api.util.KeycloakProvider;

import jakarta.ws.rs.core.Response;
//import jakarta.ws.rs.core.Response;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class KeycloakServiceImpl implements IKeycloakService {
    private final SubscriptionRepository subscriptionRepository;
    private static final Logger logger = LogManager.getLogger();
    private final UserRepository userRepository;

    @Override
    public ResponseEntity<com.kahoot.kahoot.api.other.Response<List<UserRepresentation>>> findAllUsers() {
        try {
            logger.info("Se va a obtener TODOS los usuarios");
            List<UserRepresentation> users = KeycloakProvider.getRealmResource().users().list();
            logger.info("Se han encontrado {} usuarios", users.size());
            return ResponseEntity.ok(new com.kahoot.kahoot.api.other.Response("Se han encontrado todos los usuarios", users));
        } catch (Exception e) {
            logger.error("Ha ocurrido un error al obtener los usuarios", e);
            return ResponseEntity.badRequest().build();
        }
    }



    @Override
    public ResponseEntity<com.kahoot.kahoot.api.other.Response<List<UserRepresentation>>> searchUserByUsername(
            String username) {
        try {
            logger.info("Se va a buscar un usuario con username: {}", username);
            List<UserRepresentation> users = KeycloakProvider.getRealmResource().users().searchByUsername(username, true);
            logger.info("Se han encontrado {} usuarios con username: {}", users.size(), username);
            return ResponseEntity
                    .ok(new com.kahoot.kahoot.api.other.Response("Se han encontrado todos los usuarios", users));
        } catch (Exception e) {
            logger.error("Ha ocurrido un error al buscar el usuario con username: {}", username, e);
            return ResponseEntity.badRequest().build();
        }
    }




    @Override
    public ResponseEntity<com.kahoot.kahoot.api.other.Response<Boolean>> createUser(@NonNull UserDTO userDTO) {
        try {
            logger.info("Se va a crear un usuario con username: {}", userDTO.getUsername());
            int status = 0;

            UsersResource userResource = KeycloakProvider.getUserResource();
            UserRepresentation userRepresentation = new UserRepresentation();
            userRepresentation.setEmail(userDTO.getEmail());
            userRepresentation.setUsername(userDTO.getUsername());
            userRepresentation.setFirstName("_");
            userRepresentation.setLastName("_");
            userRepresentation.setEmailVerified(true);
            userRepresentation.setEnabled(true);

            Response response = userResource.create(userRepresentation);
            status = response.getStatus();

            logger.info("Status after creating user: {}", status);

            if (status == 201) {
                String path = response.getLocation().getPath();
                String userId = path.substring(path.lastIndexOf('/') + 1);
                logger.info("User ID: {}", userId);

                CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
                credentialRepresentation.setTemporary(false);
                credentialRepresentation.setType(OAuth2Constants.PASSWORD);
                credentialRepresentation.setValue(userDTO.getPassword());

                userResource.get(userId).resetPassword(credentialRepresentation);
                RealmResource realmResource = KeycloakProvider.getRealmResource();
                List<RoleRepresentation> roleRepresentations = null;

                if (userDTO.getRoles() == null || userDTO.getRoles().isEmpty()) {
                    roleRepresentations = List.of(realmResource.roles().get("user").toRepresentation());
                } else {
                    roleRepresentations = realmResource.roles()
                            .list()
                            .stream()
                            .filter(role -> userDTO.getRoles()
                                    .stream()
                                    .anyMatch(roleName -> roleName.equalsIgnoreCase(role.getName())))
                            .toList();
                }

                realmResource.users()
                        .get(userId)
                        .roles()
                        .realmLevel()
                        .add(roleRepresentations);

                User user = new User();
                user.setId(userId);
                userRepository.save(user);
                return ResponseEntity.ok(new com.kahoot.kahoot.api.other.Response<>("User created successfully", true));
            } else if (status == 409) {
                logger.error("User already exists");
                return ResponseEntity.ok(new com.kahoot.kahoot.api.other.Response<>("User Already Exists", null));
            } else {
                logger.error("Error creating user");
                return ResponseEntity.ok(new com.kahoot.kahoot.api.other.Response<>("Error creating user", null));
            }
        } catch (Exception e) {
            logger.error("Ha ocurrido un error al crear el usuario", e);
            return ResponseEntity.badRequest().build();
        }
    }

    @Override
    public ResponseEntity<com.kahoot.kahoot.api.other.Response<UserDTO>> deleteUser(String userId) {
        try {
            logger.info("Se va a eliminar el usuario con id: {}", userId);
            KeycloakProvider.getUserResource()
                    .get(userId)
                    .remove();
            logger.info("Usuario eliminado");
            return ResponseEntity
                    .ok(new com.kahoot.kahoot.api.other.Response("User Deleted", null));
        } catch (Exception e) {
            logger.error("Ha ocurrido un error al eliminar el usuario con id: {}", userId, e);
            return ResponseEntity.badRequest().build();
        }
    }

    @Override
    public ResponseEntity<com.kahoot.kahoot.api.other.Response<UserDTO>> updateUser(String userId,
            @NonNull UserDTO userDTO) {
        try {
            logger.info("Se va a actualizar el usuario con id: {}", userId);
            CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
            credentialRepresentation.setTemporary(false);
            credentialRepresentation.setType(OAuth2Constants.PASSWORD);
            credentialRepresentation.setValue(userDTO.getPassword());

            UserRepresentation userRepresentation = new UserRepresentation();
            userRepresentation.setEmail(userDTO.getEmail());
            userRepresentation.setUsername(userDTO.getUsername());
            userRepresentation.setEmailVerified(true);
            userRepresentation.setEnabled(true);
            userRepresentation.setCredentials(Collections.singletonList(credentialRepresentation));

            UserResource userResource = KeycloakProvider.getUserResource().get(userId);
            userResource.update(userRepresentation);
            UserDTO userDto = new UserDTO();
            userDto.setId(userId);
            userDto.setEmail(userRepresentation.getEmail());
            userDto.setUsername(userRepresentation.getUsername());
            logger.info("Usuario actualizado");
            return ResponseEntity
                    .ok(new com.kahoot.kahoot.api.other.Response("Usuario actualizado", userDto));
        } catch (Exception e) {
            logger.error("Ha ocurrido un error al actualizar el usuario con id: {}", userId, e);
            return ResponseEntity.badRequest().build();
        }
    }



}
