package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.SubscriptionDTO;
import com.kahoot.kahoot.api.entities.Subscription;
import com.kahoot.kahoot.api.mappers.SubscriptionMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.SubscriptionRepository;
import com.kahoot.kahoot.api.services.SubscriptionService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class SubscriptionServiceImp implements SubscriptionService {


    private static final Logger logger = LogManager.getLogger();

    private SubscriptionMapper subscriptionMapper;

    private SubscriptionRepository subscriptionRepository;

    @Override
    public ResponseEntity<Response<SubscriptionDTO>> findById(int id) {

        try {
            logger.info("Buscando suscripcion con id={}", id);
            Optional<Subscription> subscriptionOpt = subscriptionRepository.findById(id);
            ResponseEntity<Response<SubscriptionDTO>> response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<SubscriptionDTO>("No se ha encontrado la suscripción", null));
            if (subscriptionOpt.isPresent()) {
                Subscription subscription = subscriptionOpt.get();
                logger.info("Se ha encontrado la suscripcion con id={}", subscription.getId());
                SubscriptionDTO subscriptionDTO = subscriptionMapper.toDTO(subscription);
                response = ResponseEntity.status(HttpStatus.OK).body(new Response<SubscriptionDTO>("Se ha encontrado la suscripción", subscriptionDTO));
            }
            return response;
        } catch (Exception e) {
            logger.error("Error 500 al buscar suscripcion por id", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<SubscriptionDTO>("Error del servidor", null));

        }
    }

    @Override
    public ResponseEntity<Response<SubscriptionDTO>> findByName(String name) {

        try {
            logger.info("Buscando suscripcion con nombre={}", name);
            Optional<Subscription> subscriptionOpt = subscriptionRepository.findByName(name);
            ResponseEntity<Response<SubscriptionDTO>> response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<SubscriptionDTO>("No se ha encontrado la suscripción", null));
            if (subscriptionOpt.isPresent()) {
                Subscription subscription = subscriptionOpt.get();
                logger.info("Se ha encontrado la suscripcion con id={}", subscription.getId());
                SubscriptionDTO subscriptionDTO = subscriptionMapper.toDTO(subscription);
                response = ResponseEntity.status(HttpStatus.OK).body(new Response<SubscriptionDTO>("Se ha encontrado la suscripción", subscriptionDTO));
            }
            return response;
        } catch (Exception e) {
            logger.error("Error 500 al buscar suscripcion por nombre", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<SubscriptionDTO>("Error del servidor", null));
        }
    }

    @Override
    public ResponseEntity<Response<SubscriptionDTO>> save(SubscriptionDTO subscriptionDTO) {

        try {
            logger.info("Guardando suscripcion con nombre={}", subscriptionDTO.getName());
            Subscription savedSubscription = subscriptionRepository.save(subscriptionMapper.toEntity(subscriptionDTO));
            logger.info("Se ha guardado la suscripcion con id={}", savedSubscription.getId());
            SubscriptionDTO savedSubscriptionDTO = subscriptionMapper.toDTO(savedSubscription);
            return ResponseEntity.status(HttpStatus.CREATED).body(new Response<SubscriptionDTO>("Se ha guardado la suscripción", savedSubscriptionDTO));
        } catch (Exception e) {
            logger.error("Error 500 al guardar suscripcion", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<SubscriptionDTO>("Error del servidor", null));
        }

    }

    @Override
    public ResponseEntity<Response<SubscriptionDTO>> delete(int id) {

        try {
            logger.info("Borrando suscripcion con id={}", id);
            Optional<Subscription> subscriptionOpt = subscriptionRepository.findById(id);
            ResponseEntity<Response<SubscriptionDTO>> response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<SubscriptionDTO>("No se ha encontrado la suscripción", null));
            if (subscriptionOpt.isPresent()) {
                Subscription deletedSubscription = subscriptionOpt.get();
                logger.info("Se ha encontrado la suscripcion con id={}", deletedSubscription.getId());
                subscriptionRepository.delete(deletedSubscription);
                logger.info("Se ha borrado la suscripcion con id={}", deletedSubscription.getId());
                 SubscriptionDTO subscriptionDTO = subscriptionMapper.toDTO(deletedSubscription);
           response = ResponseEntity.status(HttpStatus.OK).body(new Response<SubscriptionDTO>("Se ha borrado la suscripción", subscriptionDTO));
            }
            return response;
        } catch (Exception e) {
            logger.error("Error 500 al borrar suscripcion", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<SubscriptionDTO>("Error del servidor", null));

        }
    }

    @Override
    public ResponseEntity<Response<SubscriptionDTO>> update(SubscriptionDTO subscriptionDTO, int id) {
        try {
            logger.info("Actualizando suscripcion con id={}", id);
            Optional<Subscription> subscriptionOpt = subscriptionRepository.findById(id);
            ResponseEntity<Response<SubscriptionDTO>> response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<SubscriptionDTO>("No se ha encontrado la suscripción", null));
            if (subscriptionOpt.isPresent()) {
                Subscription updatedSubscription = subscriptionOpt.get();
                logger.info("Se ha encontrado la suscripcion con id={}", updatedSubscription.getId());
                updatedSubscription.setName(subscriptionDTO.getName());
    

                updatedSubscription.setDescription(subscriptionDTO.getDescription());
                updatedSubscription.setPrice(subscriptionDTO.getPrice());
                updatedSubscription.setSubscribers(subscriptionDTO.getSubscribers());
                subscriptionRepository.save(updatedSubscription);
                logger.info("Se ha actualizado la suscripcion con id={}", updatedSubscription.getId());
                SubscriptionDTO savedSubscriptionDTO = subscriptionMapper.toDTO(updatedSubscription);
                response = ResponseEntity.status(HttpStatus.OK).body(new Response<SubscriptionDTO>("Se ha actualizado la suscripción", savedSubscriptionDTO));
            }
            return response;
        } catch (Exception e) {
            logger.error("Error 500 al actualizar suscripcion", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<SubscriptionDTO>("Error del servidor", null));

        }
    }

    @Override
    public ResponseEntity<Response<List<SubscriptionDTO>>> findAll() {

        try {
            logger.info("Buscando todas las suscripciones");
            List<Subscription> subscriptions = subscriptionRepository.findAll();
            List<SubscriptionDTO> subscriptionDTOs = new ArrayList<>();
            for (Subscription subscription : subscriptions) {
                SubscriptionDTO subscriptionDTO = subscriptionMapper.toDTO(subscription);
                subscriptionDTOs.add(subscriptionDTO);
            }
            return ResponseEntity.status(HttpStatus.OK).body(new Response<List<SubscriptionDTO>>("Se han encontrado las suscripciones", subscriptionDTOs));
        } catch (Exception e) {
            logger.error("Error 500 al buscar todas las suscripciones", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new Response<List<SubscriptionDTO>>("Error del servidor", null));
        }
    }

   
}

