package com.kahoot.kahoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KahootApplicationTests {

	@Test
	void contextLoads() {
	}

}
