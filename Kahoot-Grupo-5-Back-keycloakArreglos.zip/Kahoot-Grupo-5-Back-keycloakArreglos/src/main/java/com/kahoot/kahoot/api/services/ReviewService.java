package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.ReviewDTO;
import com.kahoot.kahoot.api.entities.Review;
import com.kahoot.kahoot.api.other.Response;

public interface ReviewService {
    ResponseEntity<Response<ReviewDTO>> findById(int id);
    ResponseEntity<Response<ReviewDTO>> save(ReviewDTO reviewDTO, String idUser, int idForm);
    ResponseEntity<Response<ReviewDTO>> delete(int id);
    ResponseEntity<Response<ReviewDTO>> update(ReviewDTO reviewDTO, int id);
    ResponseEntity<Response<List<ReviewDTO>>> findAll();

}
