package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.QuestionDTO;
import com.kahoot.kahoot.api.entities.Question;
import com.kahoot.kahoot.api.other.Response;


public interface QuestionService {
    ResponseEntity<Response<QuestionDTO>> findById(int id);

    ResponseEntity<Response<QuestionDTO>> save(QuestionDTO questionDTO, int idForm);
    ResponseEntity<Response<QuestionDTO>> delete(int id);
    ResponseEntity<Response<QuestionDTO>> update(QuestionDTO questionDTO, int id);
    ResponseEntity<Response<List<QuestionDTO>>> findAll();

}
