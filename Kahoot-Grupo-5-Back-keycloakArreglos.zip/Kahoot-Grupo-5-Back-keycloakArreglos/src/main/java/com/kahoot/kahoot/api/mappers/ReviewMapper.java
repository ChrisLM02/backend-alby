package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.ReviewDTO;
import com.kahoot.kahoot.api.entities.Review;


@Component

public class  ReviewMapper {

   
    public List<ReviewDTO> toDTOList(List<Review> reviewList) {
        return reviewList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Review> toEntityList(List<ReviewDTO> reviewDTOList) {
        return reviewDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }



    public ReviewDTO toDTO(Review review) {
        ReviewDTO reviewDTO = null;
        if (review != null) {
            reviewDTO = new ReviewDTO();
            reviewDTO.setId(review.getId());
            
            reviewDTO.setScore(review.getScore());
          

        }
        return reviewDTO;
    }

    public Review toEntity(ReviewDTO reviewDTO) {
        Review review = null;
        if (reviewDTO != null) {
            review = new Review();
            review.setId(reviewDTO.getId());
           
            review.setScore(reviewDTO.getScore());
           
        }
        return review;
    }



}