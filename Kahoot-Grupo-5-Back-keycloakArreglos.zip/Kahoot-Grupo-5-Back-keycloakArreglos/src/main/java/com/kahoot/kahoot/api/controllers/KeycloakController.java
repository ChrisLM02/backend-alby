package com.kahoot.kahoot.api.controllers;

import java.util.List;

import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.UserDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.services.IKeycloakService;

@RestController
@RequestMapping("/keycloak/user")
//@PreAuthorize("hasRole('admin_client_role')")
public class KeycloakController {

    @Autowired
    private IKeycloakService keycloakService;

    @GetMapping("/search")
    public ResponseEntity<Response<List<UserRepresentation>>> findAllUsers() {
        return keycloakService.findAllUsers();
    }

    @GetMapping("/search/{username}")
    public ResponseEntity<Response<List<UserRepresentation>>> findByUsername(@PathVariable String username) {
        return keycloakService.searchUserByUsername(username);
    }
//
    @PostMapping("/create")
    public ResponseEntity<Response<Boolean>> createUser(@RequestBody UserDTO userDTO) {
        System.out.println("Creando usuario: " + userDTO.getUsername());
        ResponseEntity<Response<Boolean>> response = keycloakService.createUser(userDTO);
        System.out.println("Usuario creado: " + userDTO.getUsername());


        return response;
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<Response<UserDTO>> updateUser(@PathVariable String userId, @RequestBody UserDTO userDTO) {
        return keycloakService.updateUser(userId, userDTO);

    }

    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<Response<UserDTO>> deleteUser(@PathVariable String userId) {
        return keycloakService.deleteUser(userId);

    }
}
