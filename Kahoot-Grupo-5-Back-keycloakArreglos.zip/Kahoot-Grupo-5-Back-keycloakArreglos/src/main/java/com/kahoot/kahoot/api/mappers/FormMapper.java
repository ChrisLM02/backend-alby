package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.FormDTO;
import com.kahoot.kahoot.api.entities.Form;

@Component
public class FormMapper {
    
   
    @Autowired
    QuestionMapper questionMapper;
    @Autowired
    ReviewMapper reviewMapper;


    public FormDTO toDTO(Form form) {
        FormDTO formDTO = null;
        if (form != null) {
            formDTO = new FormDTO();
            formDTO.setId(form.getId());
            formDTO.setTitle(form.getTitle());
            
            formDTO.setReviews(reviewMapper.toDTOList(form.getReviews()));
            formDTO.setQuestions(questionMapper.toDTOList(form.getQuestions()));
          


        }
        return formDTO;
    }

    public Form toEntity(FormDTO formDTO) {
        Form form = null;
        if (formDTO != null) {
            form = new Form();
            form.setId(formDTO.getId());
            form.setTitle(formDTO.getTitle());
       
            form.setReviews(reviewMapper.toEntityList(formDTO.getReviews()));
            form.setQuestions(questionMapper.toEntityList(formDTO.getQuestions()));
      
        }
        return form;
    }

    public List<Form> toEntityList(List<FormDTO> formDTOList) {
        return formDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }

    public List<FormDTO> toDTOList(List<Form> formList) {
        return formList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }



}