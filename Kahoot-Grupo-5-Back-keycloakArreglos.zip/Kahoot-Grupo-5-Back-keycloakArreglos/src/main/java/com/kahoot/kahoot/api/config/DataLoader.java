package com.kahoot.kahoot.api.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.entities.Category;
import com.kahoot.kahoot.api.entities.Subscription;
import com.kahoot.kahoot.api.repositories.CategoryRepository;
import com.kahoot.kahoot.api.repositories.SubscriptionRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final SubscriptionRepository subscriptionRepository; // Suponiendo que tienes un repositorio para tus roles

    private final CategoryRepository categoryRepository;

    private boolean subsLoaded = false;
    private boolean catgEnabled = false;

    @Override
    public void run(String... args) throws Exception {

        if (!subsLoaded) {
            // Verificar si las subscripciones ya existen en la base de datos
            if (subscriptionRepository.count() == 0) {
                // Si no existen, cargar las subscripciones
                subscriptionRepository
                        .save(Subscription.builder().name("Free").price(0).subscribers(4)
                                .description("Up to 4 players per Session for Free").build());
                subscriptionRepository
                        .save(Subscription.builder().name("Premium").price(12).subscribers(12)
                                .description("Up to 12 players per Session").build());

                subsLoaded = true;
            } else {
                // Si ya existen, marcar la bandera como true para evitar recargas
                subsLoaded = true;
            }

        }
        if (!catgEnabled) {
            // Verificar si las categorias ya existen en la base de datos
            if (categoryRepository.count() == 0) {
                // Si no existen, cargar las categorias
                categoryRepository.save(Category.builder().name("Geography").build());
                categoryRepository.save(Category.builder().name("Science").build());
                categoryRepository.save(Category.builder().name("Art").build());
                categoryRepository.save(Category.builder().name("Sports").build());
                categoryRepository.save(Category.builder().name("Music").build());

                categoryRepository.save(Category.builder().name("Film").build());
                categoryRepository.save(Category.builder().name("Other").build());

                catgEnabled = true;
            } else {
                // Si ya existen, marcar la bandera como true para evitar recargas
                catgEnabled = true;
            }

        }
    }
}
