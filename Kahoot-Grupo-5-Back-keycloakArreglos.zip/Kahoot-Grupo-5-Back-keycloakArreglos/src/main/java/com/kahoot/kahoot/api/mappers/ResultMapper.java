package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.ResultDTO;
import com.kahoot.kahoot.api.entities.Result;

@Component
public class ResultMapper {
  

    public ResultDTO toDTO(Result result) {
        ResultDTO resultDTO = null;
        if (result != null) {
            resultDTO = new ResultDTO();
            resultDTO.setId(result.getId());

            resultDTO.setScore(result.getScore());

        }
        return resultDTO;
    }

    public Result toEntity(ResultDTO resultDTO) {
        Result result = null;
        if (resultDTO != null) {
            result = new Result();
            result.setId(resultDTO.getId());

            // Aquí necesitarás convertir la lista de UserDTO a una lista de User
            result.setScore(resultDTO.getScore());

        }
        return result;
    }

    public List<ResultDTO> toDTOList(List<Result> resultList) {
        return resultList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<Result> toEntityList(List<ResultDTO> resultDTOList) {
        return resultDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }

}