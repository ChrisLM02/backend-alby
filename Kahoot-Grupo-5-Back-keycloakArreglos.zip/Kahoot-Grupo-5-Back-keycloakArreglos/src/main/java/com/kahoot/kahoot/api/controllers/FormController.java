package com.kahoot.kahoot.api.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.FormDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.servicesimp.FormServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping(value="/api/v1/forms")
@RequiredArgsConstructor
@CrossOrigin(origins= {"http://localhost:4200"})
public class FormController {

    private final FormServiceImp formServiceImp;

    @Operation(summary = "Creates a new form", description = "Returns the created form", tags = { "forms" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Form created", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "409", description = "Conflict", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Response.class)))
    })
    @PostMapping("/{idUser}")
    public ResponseEntity<Response<FormDTO>> createForm(@RequestBody FormDTO formDTO, @Parameter(description = "The user's id", required = true) @PathVariable String idUser, @Parameter(description = "The list of categories' id", required = true) @RequestParam Integer idCategories) {
        return formServiceImp.save(formDTO, idUser, idCategories);
    }

    @Operation(summary = "Returns all the forms", description = "Returns all the forms", tags = { "forms" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Forms found", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Response.class)))
    })
    @GetMapping
    public ResponseEntity<Response<List<FormDTO>>> getAllForms() {
        return formServiceImp.findAll();
    }

    @Operation(summary = "Returns a form by its id", description = "Returns a form by its id", tags = { "forms" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form found", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Response.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Response<FormDTO>> getFormById(@Parameter(description = "The form's id", required = true) @PathVariable int id) {
        return formServiceImp.findById(id);
    }

    @Operation(summary = "Deletes a form by its id", description = "Deletes a form by its id", tags = { "forms" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form deleted", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Response.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<FormDTO>> deleteForm(@Parameter(description = "The form's id", required = true) @PathVariable int id) {
        return formServiceImp.delete(id);
    }

    @Operation(summary = "Updates a form by its id", description = "Updates a form by its id", tags = { "forms" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Form updated", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Response.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Response<FormDTO>> updateForm(@Parameter(description = "The form's id", required = true) @PathVariable int id, @RequestBody FormDTO formDTO) {
        return formServiceImp.update(formDTO, id);
    }


}


