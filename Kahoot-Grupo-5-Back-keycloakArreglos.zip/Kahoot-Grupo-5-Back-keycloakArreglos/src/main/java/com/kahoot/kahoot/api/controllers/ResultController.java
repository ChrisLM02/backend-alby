package com.kahoot.kahoot.api.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.ResultDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.servicesimp.ResultServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping(value="/api/v1/results")
@RequiredArgsConstructor
@CrossOrigin(origins= {"http://localhost:4200"})
public class ResultController {

	private final ResultServiceImp resultServiceImp;
	
	@Operation(summary = "Create a Result", description = "Creates a Result in the database")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Result created", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
    @PostMapping
    public ResponseEntity<Response<ResultDTO>> createResult(@RequestBody ResultDTO resultDTO, @RequestParam String idUser, @RequestParam int idMatch) {
        return resultServiceImp.save(resultDTO, idUser, idMatch);
    }
	
	@Operation(summary = "Get all Results", description = "Returns all Results in the database")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "All Results", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
    @GetMapping
    public ResponseEntity<Response<List<ResultDTO>>> getAllResults() {
        return resultServiceImp.findAll();
    }
	
	@Operation(summary = "Get a Result by id", description = "Returns a Result by id in the database")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Result found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Result not found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
    @GetMapping("/{id}")
    public ResponseEntity<Response<ResultDTO>> getResultById(@PathVariable int id) {
        return resultServiceImp.findById(id);
    }
	
	@Operation(summary = "Delete a Result by id", description = "Deletes a Result by id in the database")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Result deleted", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Result not found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<ResultDTO>> deleteResult(@PathVariable int id) {
        return resultServiceImp.delete(id);
    }
	
	@Operation(summary = "Update a Result by id", description = "Updates a Result by id in the database")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Result updated", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "404", description = "Result not found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
	})
    @PutMapping("/{id}")
    public ResponseEntity<Response<ResultDTO>> updateResult(@PathVariable int id, @RequestBody ResultDTO resultDTO) {
        return resultServiceImp.update(resultDTO, id);
    }



}

