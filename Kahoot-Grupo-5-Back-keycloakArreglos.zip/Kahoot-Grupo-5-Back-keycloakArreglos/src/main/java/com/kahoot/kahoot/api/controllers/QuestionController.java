package com.kahoot.kahoot.api.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kahoot.kahoot.api.dtos.QuestionDTO;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.servicesimp.QuestionServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping(value="/api/v1/questions")
@RequiredArgsConstructor
@CrossOrigin(origins= {"http://localhost:4200"})
public class QuestionController {

    private final QuestionServiceImp questionServiceImp;

    @Operation(summary = "Create a question", description = "Create a question")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Question created", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))})
    })
    @PostMapping("/{idForm}")
    public ResponseEntity<Response<QuestionDTO>> createQuestion(@PathVariable int idForm ,@RequestBody QuestionDTO questionDTO) {
        return questionServiceImp.save(questionDTO, idForm);
    }

    @Operation(summary = "Get all questions", description = "Get all questions")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Questions list", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))})
    })
    @GetMapping
    public ResponseEntity<Response<List<QuestionDTO>>> getAllQuestions() {
        return questionServiceImp.findAll();
    }

    @Operation(summary = "Get question by id", description = "Get question by id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Question found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "404", description = "Question not found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))})
    })
    @GetMapping("/{id}")
    public ResponseEntity<Response<QuestionDTO>> getQuestionById(@PathVariable int id) {
        return questionServiceImp.findById(id);
    }

    @Operation(summary = "Delete a question by id", description = "Delete a question by id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Question deleted", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "404", description = "Question not found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))})
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<QuestionDTO>> deleteQuestion(@PathVariable int id) {
        return questionServiceImp.delete(id);
    }

    @Operation(summary = "Update a question by id", description = "Update a question by id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Question updated", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "404", description = "Question not found", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))})
    })
    @PutMapping("/{id}")
    public ResponseEntity<Response<QuestionDTO>> updateQuestion(@PathVariable int id, @RequestBody QuestionDTO questionDTO) {
        return questionServiceImp.update(questionDTO, id);
    }

}

