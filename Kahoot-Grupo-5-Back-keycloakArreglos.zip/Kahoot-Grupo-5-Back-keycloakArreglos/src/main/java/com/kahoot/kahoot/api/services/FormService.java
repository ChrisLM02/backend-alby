package com.kahoot.kahoot.api.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.FormDTO;
import com.kahoot.kahoot.api.entities.Form;
import com.kahoot.kahoot.api.other.Response;

public interface FormService {

    ResponseEntity<Response<FormDTO>> findById(int id);
    ResponseEntity<Response<FormDTO>> save(FormDTO formDTO, String idUser, Integer idCategories);
    ResponseEntity<Response<FormDTO>> delete(int id);
    ResponseEntity<Response<FormDTO>> update(FormDTO formDTO, int id);
    ResponseEntity<Response<List<FormDTO>>> findAll();

}
