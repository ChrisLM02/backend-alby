package com.kahoot.kahoot.api.mappers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kahoot.kahoot.api.dtos.UserDTO;
import com.kahoot.kahoot.api.entities.User;

@Component

public class UserMapper {
    @Autowired
    private SubscriptionMapper subscriptionMapper;

    public UserDTO toDTO(User user) {
        UserDTO userDTO = null;
        if (user != null) {
            userDTO = new UserDTO();
            userDTO.setId(user.getId());

        }
        return userDTO;
    }

    public User toEntity(UserDTO userDTO) {
        User user = null;
        if (userDTO != null) {
            user = new User();
            user.setId(userDTO.getId());

        }
        return user;
    }

    public List<UserDTO> toDTOList(List<User> userList) {
        return userList.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<User> toEntityList(List<UserDTO> userDTOList) {
        return userDTOList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }

}

/*
 * 
 * LLAMADAS A LOS METODOS
 * 
 * UserDTO userDTO = UserMapper.INSTANCE.userToUserDTO(userEntity);
 * User userEntity = UserMapper.INSTANCE.userDTOToUser(userDTO);
 * 
 */