package com.kahoot.kahoot.api.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kahoot.kahoot.api.entities.Result;

public interface ResultRepository extends JpaRepository<Result,Integer>{}