package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.QuestionDTO;
import com.kahoot.kahoot.api.entities.Form;
import com.kahoot.kahoot.api.entities.Question;
import com.kahoot.kahoot.api.mappers.QuestionMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.FormRepository;
import com.kahoot.kahoot.api.repositories.QuestionRepository;
import com.kahoot.kahoot.api.services.QuestionService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class QuestionServiceImp implements QuestionService {

    private static final Logger logger = LogManager.getLogger();
    private QuestionMapper questionMapper;
    private QuestionRepository questionRepository;
    private FormRepository formRepository;

    

    @Override
    public ResponseEntity<Response<QuestionDTO>> findById(int id) {
        try {
            logger.info("Buscando pregunta con id: " + id);
            Question question = questionRepository.findById(id).orElse(null);
            if (question == null) {
                logger.warn("Pregunta no encontrada");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<QuestionDTO>("Pregunta no encontrada", null));
            }
            QuestionDTO questionDTO = questionMapper.toDTO(question);
            logger.info("Se ha encontrado la pregunta: " + questionDTO);
            return ResponseEntity.ok(new Response<QuestionDTO>("Se ha encontrado la pregunta", questionDTO));
        } catch (Exception e) {
            logger.error("Internal Server Error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<QuestionDTO>> delete(int id) {
        try {
            logger.info("Borrando pregunta con id: " + id);
            Question question = questionRepository.findById(id).orElse(null);
            if (question == null) {
                logger.warn("Pregunta no encontrada");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<QuestionDTO>("Pregunta no encontrada", null));
            }
            questionRepository.delete(question);
            QuestionDTO questionDTO = questionMapper.toDTO(question);
            logger.info("Se ha borrado la pregunta: " + questionDTO);
            return ResponseEntity.ok(new Response<QuestionDTO>("Se ha borrado la pregunta", questionDTO));
        } catch (Exception e) {
            logger.error("Internal Server Error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<QuestionDTO>> update(QuestionDTO questionDTO, int id) {
        try {
            logger.info("Actualizando pregunta con id: " + id);
            Question question = questionRepository.findById(id).orElse(null);
            if (question == null) {
                logger.warn("Pregunta no encontrada");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<QuestionDTO>("Pregunta no encontrada", null));
            }
            question.setTitle(questionDTO.getTitle());
            question.setTimer(questionDTO.getTimer());

            questionRepository.save(question);
            QuestionDTO updatedQuestionDTO  = questionMapper.toDTO(question);
            logger.info("Se ha actualizado la pregunta: " + updatedQuestionDTO);
            return ResponseEntity.ok(new Response<QuestionDTO>("Se ha actualizado la pregunta", updatedQuestionDTO));

        } catch (Exception e) {
            logger.error("Internal Server Error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<List<QuestionDTO>>> findAll() {
        try {
            logger.info("Buscando todas las preguntas");
            List<Question> questions = questionRepository.findAll();
            List<QuestionDTO> questionDTOs = new ArrayList<>();
            for (Question question : questions) {
                questionDTOs.add(questionMapper.toDTO(question));
                logger.info("Se ha encontrado la pregunta: " + questionDTOs.get(questionDTOs.size()-1));

            }
            return ResponseEntity.ok(new Response<List<QuestionDTO>>("Se han encontrado las preguntas", questionDTOs));
        } catch (Exception e) {
            logger.error("Internal Server Error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<QuestionDTO>> save(QuestionDTO questionDTO, int idForm) {
        try {
            logger.info("Guardando nueva pregunta");
            Form form = formRepository.findById(idForm).orElse(null);
            if (form == null) {
                logger.warn("Formulario no encontrado");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new Response<QuestionDTO>("Formulario no encontrado", null));
            }
            Question question = questionMapper.toEntity(questionDTO);
            question.setForm(form);
            //question.save(form) prueba
            form.addQuestions(question);
            formRepository.save(form);
            QuestionDTO savedQuestionDTO = questionMapper.toDTO(question);
            logger.info("Se ha guardado la pregunta: " + savedQuestionDTO);
            return ResponseEntity.ok(new Response<QuestionDTO>("Se ha creado la pregunta", savedQuestionDTO));

        } catch (Exception e) {
            logger.error("Internal Server Error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

}


