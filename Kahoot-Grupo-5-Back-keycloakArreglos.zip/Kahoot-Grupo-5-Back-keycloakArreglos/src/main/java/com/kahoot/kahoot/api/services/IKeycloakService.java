package com.kahoot.kahoot.api.services;

import java.util.List;

import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.ResponseEntity;

import com.kahoot.kahoot.api.dtos.UserDTO;
import com.kahoot.kahoot.api.other.Response;

public interface IKeycloakService {

    ResponseEntity<Response<List<UserRepresentation>>> findAllUsers();
    ResponseEntity<Response<List<UserRepresentation>>> searchUserByUsername(String username);
    ResponseEntity<Response<Boolean>> createUser (UserDTO userDTO);
    ResponseEntity<Response<UserDTO>> deleteUser(String userId);
    ResponseEntity<Response<UserDTO>> updateUser(String userId, UserDTO userDTO);

}
