package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.FormDTO;
import com.kahoot.kahoot.api.entities.Category;
import com.kahoot.kahoot.api.entities.Form;
import com.kahoot.kahoot.api.entities.User;
import com.kahoot.kahoot.api.mappers.FormMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.AnswerRepository;
import com.kahoot.kahoot.api.repositories.CategoryRepository;
import com.kahoot.kahoot.api.repositories.FormRepository;
import com.kahoot.kahoot.api.repositories.UserRepository;
import com.kahoot.kahoot.api.services.FormService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class FormServiceImp implements FormService {

    private static final Logger logger = LogManager.getLogger();

    private FormMapper formMapper;
    private FormRepository formRepository;
    private UserRepository userRepository;
    private CategoryRepository categoryRepository;
    private AnswerRepository answerRepository;

    @Override
    public ResponseEntity<Response<FormDTO>> findById(int id) {
        try {
            logger.info("Buscando formulario con id: " + id);
            Form form = formRepository.findById(id).orElse(null);
            if (form == null) {
                logger.warn("No se ha encontrado el formulario con id: " + id);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<FormDTO>("No se ha encontrado el formulario", null));
            }
            FormDTO formDTO = formMapper.toDTO(form);
            logger.info("Se ha encontrado el formulario con id: " + id + ". DTO: " + formDTO);
            return ResponseEntity.ok(new Response<FormDTO>("Se ha encontrado el formulario", formDTO));
        } catch (Exception e) {
            logger.error("Error al buscar formulario con id: " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<FormDTO>> delete(int id) {
        try {
            logger.info("Borrando formulario con id: " + id);
            Form deletedForm = formRepository.findById(id).orElse(null);
            if (deletedForm == null) {
                logger.warn("No se ha encontrado el formulario con id: " + id);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<FormDTO>("No se ha encontrado el formulario", null));
            }

            formRepository.delete(deletedForm);
            logger.info("Se ha borrado el formulario con id: " + id);

            return ResponseEntity.ok(new Response<FormDTO>("Se ha borrado el formulario", null));
        } catch (Exception e) {
            logger.error("Error al borrar formulario con id: " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<FormDTO>> update(FormDTO formDTO, int id) {
        try {
            logger.info("Actualizando formulario con id: " + id);
            Form updatedForm = formRepository.findById(id).orElse(null);
            if (updatedForm == null) {
                logger.warn("No se ha encontrado el formulario con id: " + id);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<FormDTO>("No se ha encontrado el formulario", null));
            }

            updatedForm.setTitle(formDTO.getTitle());
            formRepository.save(updatedForm);
            logger.info("Se ha actualizado el formulario con id: " + id + ". DTO: " + formDTO);
            return ResponseEntity.ok(new Response<FormDTO>("Se ha actualizado el formulario", formDTO));
        } catch (Exception e) {
            logger.error("Error al actualizar formulario con id: " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<List<FormDTO>>> findAll() {
        try {
            logger.info("Buscando todos los formularios");
            List<Form> forms = formRepository.findAll();
            List<FormDTO> formDTOs = new ArrayList<>();
            for (Form form : forms) {
                FormDTO formDTO = formMapper.toDTO(form);
                formDTOs.add(formDTO);
            }
            logger.info("Se han encontrado los formularios: " + formDTOs);
            return ResponseEntity.ok(new Response<List<FormDTO>>("Se han encontrado los formularios", formDTOs));
        } catch (Exception e) {
            logger.error("Error al buscar todos los formularios", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<FormDTO>> save(FormDTO formDTO, String idUser, Integer idCategories) {
        try {
            logger.info("Guardando formulario. DTO: " + formDTO);
            User user = userRepository.findById(idUser).orElse(null);
            if (user == null) {
                logger.warn("No se ha encontrado el usuario con id: " + idUser);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<FormDTO>("No se ha encontrado el usuario", null));
            }


            Category category = categoryRepository.findById(idCategories).orElse(null);
            if (category == null) {
                logger.warn("No se ha encontrado las categorías con id: " + idCategories);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<FormDTO>("No se ha encontrado las categorías", null));
            }


            Form form = formMapper.toEntity(formDTO);
            form.setUser(user);
            form.setCategories(category);

            form = formRepository.save(form);
            formDTO.setId(form.getId());

            user.addForms(form);

            category.addForms(form);
            categoryRepository.save(category);

            userRepository.save(user);
            logger.info("Se ha creado el formulario. Su ID es " + formDTO.getId());
            return ResponseEntity.ok(new Response<FormDTO>("Se ha creado el formulario. Su ID es " + formDTO.getId(), formDTO));

        } catch (Exception e) {
            logger.error("Error al guardar formulario. DTO: " + formDTO, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
