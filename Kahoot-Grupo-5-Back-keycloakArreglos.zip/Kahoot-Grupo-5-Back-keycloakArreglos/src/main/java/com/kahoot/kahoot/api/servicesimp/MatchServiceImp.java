package com.kahoot.kahoot.api.servicesimp;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kahoot.kahoot.api.dtos.MatchDTO;
import com.kahoot.kahoot.api.entities.Form;
import com.kahoot.kahoot.api.entities.Match;
import com.kahoot.kahoot.api.entities.Result;
import com.kahoot.kahoot.api.entities.User;
import com.kahoot.kahoot.api.mappers.MatchMapper;
import com.kahoot.kahoot.api.mappers.ResultMapper;
import com.kahoot.kahoot.api.mappers.UserMapper;
import com.kahoot.kahoot.api.other.Response;
import com.kahoot.kahoot.api.repositories.FormRepository;
import com.kahoot.kahoot.api.repositories.MatchRepository;
import com.kahoot.kahoot.api.repositories.UserRepository;
import com.kahoot.kahoot.api.services.MatchService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class MatchServiceImp implements MatchService {


    private static final Logger logger = LogManager.getLogger();
    private ResultMapper resultMapper;
    private UserMapper userMapper;
    private MatchMapper matchMapper;
    private MatchRepository matchRepository;
    private UserRepository userRepository;
    private FormRepository formRepository;

    @Override
    public ResponseEntity<Response<MatchDTO>> findById(int id) {
        try {
            logger.info("Buscando el partido con id: " + id);
            Match match = matchRepository.findById(id).orElse(null);
            if (match == null) {
                logger.warn("No se ha encontrado el partido con id: " + id);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<MatchDTO>("No se ha encontrado el partido", null));
            }
            logger.info("Se ha encontrado el partido con id: " + id);
            MatchDTO matchDTO = matchMapper.toDTO(match);
            return ResponseEntity.ok(new Response<MatchDTO>("Se ha encontrado el partido", matchDTO));
        } catch (Exception e) {
            logger.error("Error 500 al buscar el partido con id: " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @Override
    public ResponseEntity<Response<MatchDTO>> findByPin(int pin) {
        try {
            logger.info("Buscando el partido con pin: " + pin);
            Match match = matchRepository.findByPin(pin).orElse(null);
            if (match == null) {
                logger.warn("No se ha encontrado el partido con pin: " + pin);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<MatchDTO>("No se ha encontrado el partido", null));
            }
            logger.info("Se ha encontrado el partido con pin: " + pin);
            MatchDTO matchDTO = matchMapper.toDTO(match);
            return ResponseEntity.ok(new Response<MatchDTO>("Se ha encontrado el partido", matchDTO));
        } catch (Exception e) {
            logger.error("Error 500 al buscar el partido con pin: " + pin, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

   

    @Override
    public ResponseEntity<Response<MatchDTO>> delete(int id) {
        try {
            logger.info("Borrando el partido con id: " + id);
            Match deletedMatch = matchRepository.findById(id).orElse(null);
            if (deletedMatch == null) {
                logger.warn("No se ha encontrado el partido con id: " + id);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<MatchDTO>("No se ha encontrado el partido", null));
            }
            matchRepository.delete(deletedMatch);
            logger.info("Se ha borrado el partido con id: " + id);
            MatchDTO matchDTO = matchMapper.toDTO(deletedMatch);
            return ResponseEntity.ok(new Response<MatchDTO>("Se ha borrado el partido", matchDTO));
        } catch (Exception e) {
            logger.error("Error 500 al borrar el partido con id: " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Response<MatchDTO>> update(MatchDTO matchDTO, int id) {
        try {
            logger.info("Actualizando el partido con id: " + id);
            Match updatedMatch = matchRepository.findById(id).orElse(null);
            if (updatedMatch == null) {
                logger.warn("No se ha encontrado el partido con id: " + id);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<MatchDTO>("No se ha encontrado el partido", null));
            }
            updatedMatch.setPlayers(matchDTO.getPlayers());
            updatedMatch.setPin(matchDTO.getPin());
            updatedMatch.setPassword(matchDTO.getPassword());
            List<User> users = userMapper.toEntityList(matchDTO.getUsers());
            updatedMatch.setUsers(users);
            List<Result> results = resultMapper.toEntityList(matchDTO.getResults());
            updatedMatch.setResults(results);
            Form form = formRepository.getReferenceById(matchDTO.getForm().getId());
            updatedMatch.setForm(form);
            matchRepository.save(updatedMatch);
            logger.info("Se ha actualizado el partido con id: " + id);
            MatchDTO updatedMatchDTO  = matchMapper.toDTO(updatedMatch);
            return ResponseEntity.ok(new Response<MatchDTO>("Se ha actualizado el partido", updatedMatchDTO));

        } catch (Exception e) {
            logger.error("Error 500 al actualizar el partido con id: " + id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @Override
    public ResponseEntity<Response<List<MatchDTO>>> findAll() {
        try {
            logger.info("Buscando todos los partidos");
            List<Match> matches = matchRepository.findAll();
            List<MatchDTO> matchDTOs = new ArrayList<>();
            for (Match match : matches) {
                MatchDTO matchDTO = matchMapper.toDTO(match);
                matchDTOs.add(matchDTO);

            }

            logger.info("Se han encontrado todos los partidos");
            return ResponseEntity.ok(new Response<List<MatchDTO>>("Se han encontrado los Match", matchDTOs));

        } catch (Exception e) {
            logger.error("Error 500 al buscar todos los partidos", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @Override
    public ResponseEntity<Response<MatchDTO>> save(MatchDTO matchDTO, int idForm, List<String> idUsers) {
        try {
            logger.info("Creando el partido");
            Form form = formRepository.findById(idForm).orElse(null);
            if (form == null) {
                logger.warn("No se ha encontrado el formulario con id: " + idForm);
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND)
                        .body(new Response<MatchDTO>("No se ha encontrado el formulario", null));
            }
            List<User> users = new ArrayList<>();
            for (String idUser : idUsers) {
                User user = userRepository.findById(idUser).orElse(null);
                if (user == null) {
                    logger.warn("No se ha encontrado el usuario con id: " + idUser);
                    return ResponseEntity
                            .status(HttpStatus.NOT_FOUND)
                            .body(new Response<MatchDTO>("No se ha encontrado el usuario", null));
                }
                users.add(user);
            }
            Match match = matchMapper.toEntity(matchDTO);
            match.setForm(form);
            match.setUsers(users);
            matchRepository.save(match);
            logger.info("Se ha creado el partido");
            MatchDTO createdMatchDTO  = matchMapper.toDTO(match);
            return ResponseEntity.ok(new Response<MatchDTO>("Se ha creado el Match", createdMatchDTO ));
        } catch (Exception e) {
            logger.error("Error 500 al crear el partido", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        
        
    }

}


